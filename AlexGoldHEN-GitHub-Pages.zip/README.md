# AlexGoldHEN · OnyxAI — site pronto para GitHub Pages

O pacote contém o site estático de PS4 e o arquivo `goldhen.bin` fornecido com o pedido.

## Publicação em `https://alexgoldhen.github.io/`

O endereço exato só é disponibilizado pelo GitHub Pages se o **usuário ou organização GitHub** se chamar `alexgoldhen`, e existir um repositório público chamado **`alexgoldhen.github.io`** nessa conta/organização.

1. Entre na conta GitHub `alexgoldhen` (ou em uma organização com esse nome) e crie um repositório público chamado `alexgoldhen.github.io`.
2. Extraia `AlexGoldHEN-GitHub-Pages.zip` e envie os arquivos **diretamente para a raiz** do repositório — `index.html`, `app.js`, `core.js`, `styles.css`, pasta `assets/` e `goldhen.bin`, etc. Não envie apenas o ZIP como único arquivo.
3. Acesse **Settings > Pages > Build and deployment > Deploy from a branch**, escolha `main`, pasta `/(root)`, e salve.
4. Após a publicação do GitHub Pages, abra `https://alexgoldhen.github.io/` e teste em navegador comum e no PS4.

Se estiver conectado como `alexandregames032`, esse domínio exato não será criado apenas escolhendo o nome do repositório. Nesse caso, crie o repositório `alexandregames032.github.io` para o endereço `https://alexandregames032.github.io/`, ou conecte a conta `alexgoldhen`.

## Arquivos principais

- `index.html` — página de entrada.
- `styles.css`, `core.js`, `app.js` — interface, detecção e seleção de rota.
- `assets/` — identidade visual.
- `goldhen.bin` — arquivo fornecido, servido para download (não é executado pelo GitHub Pages).
- `tools/send_payload.py` — envio TCP local de um binário para BinLoader já ativo na rede privada.
- `tools/serve.py` e `serve.py` — servidor Python local para testar a interface.
- `downloads/AlexGoldHEN-OnyxAI.zip` — cópia portátil para download pelo site, sem o ZIP interno recursivo.

## Integridade do arquivo binário

`goldhen.bin` — 293120 bytes  
SHA-256: `df3f27c1b35bc7c40e3a08caab948930914dc7d0301a73b68945cf6ffe40ea12`

A integridade SHA-256 verifica apenas a correspondência com o arquivo recebido. Não verifica segurança, autenticidade, versão ou compatibilidade com firmware.

## Limitações

O GitHub Pages publica arquivos estáticos. Ele não executa os scripts Python nem injeta automaticamente o arquivo no PS4. O botão de download fornece o `.bin`; para transferi-lo ao console é necessário um BinLoader compatível e ativo (ou um host externo que cuide disso). O site encaminha a hosts de exploit de terceiros, sem implementação própria. O OnyxAI detecta informações publicadas no user-agent e não é um sistema de IA remoto. Detecções, tempos e funcionamento não são garantidos; o firmware 14.00 aparece na interface sem uma rota de execução.

## Testar antes de publicar

```bash
python serve.py --port 8000
```

Acesse `http://localhost:8000/` no computador. Para abrir pelo PS4, use o IP local do computador na mesma rede. Os hosts externos podem requerer internet.

## Créditos

AlexGoldHEN/OnyxAI e imagens conforme projeto original; hosts externos associados a [eddieygaming/ps4aio](https://github.com/eddieygaming/ps4aio); GoldHEN por SiSTRo e colaboradores. Não afiliado à Sony.
