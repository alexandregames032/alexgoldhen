#!/usr/bin/env python3
"""Serve the portable AlexGoldHEN interface over a local network."""
import argparse
from functools import partial
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
import socket


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--port", type=int, default=8000)
    parser.add_argument("--bind", default="0.0.0.0")
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error("A porta deve estar entre 1 e 65535.")
    script_dir = Path(__file__).resolve().parent
    root = script_dir if (script_dir / "index.html").is_file() else script_dir.parent
    handler = partial(SimpleHTTPRequestHandler, directory=str(root))
    try:
        server = ThreadingHTTPServer((args.bind, args.port), handler)
    except OSError as error:
        parser.exit(1, f"Não foi possível iniciar o servidor: {error}\n")
    print(f"AlexGoldHEN: http://localhost:{args.port}")
    try:
        addresses = sorted({x[4][0] for x in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET)})
        for address in addresses:
            if not address.startswith("127."):
                print(f"No PS4 na mesma rede: http://{address}:{args.port}")
    except socket.gaierror:
        print(f"No PS4: http://IP_DO_COMPUTADOR:{args.port}")
    print("Os hosts de exploit são externos. Primeiro acesso exige internet. Ctrl+C para encerrar.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
