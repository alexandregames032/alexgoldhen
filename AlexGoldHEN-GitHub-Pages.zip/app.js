(function(){
  'use strict';
  var Core=window.OnyxCore,keys=['webkit','base','relapse'],automatic=true,device=Core.detect(navigator.userAgent),running=null,elapsedTimer=null,toastTimer=null,lastFocus=null,fileRevision=0;
  function $(id){return document.getElementById(id);}
  function each(selector,fn){var elements=document.querySelectorAll(selector);for(var i=0;i<elements.length;i++){fn(elements[i],i);}}
  function visible(element,show){if(show){element.removeAttribute('hidden');}else{element.setAttribute('hidden','');}}
  function toggleClass(element,name,active){if(active){element.classList.add(name);}else{element.classList.remove(name);}}
  function message(text){var el=$('toast');el.textContent=text;visible(el,true);clearTimeout(toastTimer);toastTimer=setTimeout(function(){visible(el,false);},5000);}
  function storageGet(key){try{return localStorage.getItem(key);}catch(e){return null;}}
  function storageSet(key,value){try{localStorage.setItem(key,value);}catch(e){/* Private browsing may disable storage. */}}
  automatic=storageGet('onyx-automatic')!=='off';
  function update(){
    $('onyx-toggle').setAttribute('aria-checked',String(automatic));
    $('toggle-label').textContent=automatic?'Ativado':'Desativado';
    $('device-label').textContent=device.device;
    $('firmware-label').textContent=device.firmware?'FW '+device.firmware:'FW —';
    $('detector-description').textContent=automatic?'Seu dispositivo. Seu firmware. A rota certa.':'Você escolhe a versão exata do seu console.';
    var notice;
    if(!automatic){notice='Modo manual: selecione a versão exata em uma das faixas abaixo.';}
    else if(!device.isPS4){notice='Abra este site no navegador do PS4 para detectar o firmware e iniciar uma rota compatível.';}
    else if(!device.firmware){notice='PS4 identificado. O navegador não informou a versão do sistema; não foi possível confirmar a rota.';}
    else if(!device.engine){notice=device.firmware==='14.00'?'PS4 14.00 detectado. Ainda não há rota pública verificada para esta versão.':'PS4 '+device.firmware+' detectado. Não há uma rota verificada para essa versão nesta central.';}
    else{notice=Core.catalog[device.engine].name+' detectado com sucesso. PS4 '+device.firmware+' pronto para abrir o host compatível.';}
    $('detection-notice').querySelector('span').textContent=notice;
    toggleClass($('detection-notice'),'detected',automatic&&!!device.engine);
    for(var i=0;i<keys.length;i++){
      var key=keys[i],card=$('card-'+key),select=$('firmware-'+key),btn=card.querySelector('.launch-button');
      visible(card.querySelector('.auto-choice'),automatic);visible(card.querySelector('.manual-choice'),!automatic);
      var detected=automatic&&device.engine===key;
      toggleClass(card,'detected-card',detected);
      var check=Core.validateLaunch(device,automatic,key,select.value);
      btn.disabled=!check.ok||!!running;
      var label=check.ok?'Iniciar desbloqueio':!device.isPS4?(automatic?'Aguardando seu PS4':select.value?'Abra no seu PS4':'Selecione o firmware'):!automatic&&!select.value?'Selecione o firmware':automatic&&device.engine!==key?'Outra faixa de firmware':check.reason;
      btn.querySelector('span').textContent=label;
      card.querySelector('.auto-choice span').textContent=detected?'PS4 '+device.firmware+' · detectado':'Selecionado pelo OnyxAI';
      var status=card.querySelector('.card-status');
      status.textContent=key==='relapse'?'14.00 ainda indisponível':detected?'Firmware compatível detectado':automatic?'Detecção automática ativada':select.value?'Versão selecionada: '+select.value:'Seleção manual necessária';
      card.querySelector('.card-bottom').style.color=detected?Core.catalog[key].color:'';
    }
  }
  for(var i=0;i<keys.length;i++){
    var key=keys[i],select=$('firmware-'+key),versions=Core.catalog[key].versions;
    for(var j=0;j<versions.length;j++){var option=document.createElement('option');option.value=versions[j];option.textContent='PS4 '+versions[j];select.appendChild(option);}
    if(key==='relapse'){var unavailable=document.createElement('option');unavailable.value='14.00';unavailable.textContent='PS4 14.00 — indisponível';unavailable.disabled=true;select.appendChild(unavailable);}
    select.addEventListener('change',update);
  }
  // href plus xlink:href keeps inline icons available in older console WebKit.
  each('svg use',function(el){el.setAttributeNS('http://www.w3.org/1999/xlink','xlink:href',el.getAttribute('href'));});
  $('onyx-toggle').addEventListener('click',function(){automatic=!automatic;storageSet('onyx-automatic',automatic?'on':'off');update();});
  $('detect-again').addEventListener('click',function(){device=Core.detect(navigator.userAgent);update();message('Detecção local atualizada.');});
  function openModal(id){
    lastFocus=document.activeElement;visible($(id),true);document.body.classList.add('body-locked');$(id).querySelector('[role="dialog"]').focus();
  }
  function stopRun(){
    clearInterval(elapsedTimer);elapsedTimer=null;
    var host=$('host-container');while(host.firstChild){host.removeChild(host.firstChild);}
    if(running){$('card-'+running).classList.remove('is-running');}running=null;update();
  }
  function closeModal(id){
    if(id==='run-modal'){stopRun();}
    visible($(id),false);document.body.classList.remove('body-locked');if(lastFocus){lastFocus.focus();}
  }
  each('.modal-close',function(button){button.addEventListener('click',function(){var parent=button.parentNode.parentNode;closeModal(parent.id);});});
  each('.modal-backdrop',function(el){el.addEventListener('click',function(event){if(event.target===el){closeModal(el.id);}});});
  document.addEventListener('keydown',function(event){
    var modal=!$('run-modal').hasAttribute('hidden')?$('run-modal'):!$('info-modal').hasAttribute('hidden')?$('info-modal'):null;
    if(!modal){return;}
    if(event.key==='Escape'||event.keyCode===27){event.preventDefault();closeModal(modal.id);return;}
    if(event.key==='Tab'||event.keyCode===9){
      var all=modal.querySelectorAll('button:not(:disabled),a[href],select:not(:disabled),iframe,[tabindex="0"]'),first=all[0],last=all[all.length-1];
      if(event.shiftKey&&(document.activeElement===first||document.activeElement===modal.querySelector('[role="dialog"]'))){event.preventDefault();last.focus();}
      else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first.focus();}
    }
  });
  var guide='<p>Uma central para encontrar a rota do seu PS4 e acompanhar a execução no host da comunidade.</p><ol><li><strong>Confira a versão do console.</strong> No PS4, acesse Configurações → Sistema → Informações do sistema.</li><li><strong>Abra esta central no navegador do PS4.</strong> Com OnyxAI ligado, a faixa compatível é escolhida pelo firmware informado pelo navegador.</li><li><strong>Prefere escolher?</strong> Desligue o OnyxAI e selecione a versão exata em uma das três faixas. A central confere a seleção com a versão detectada.</li><li><strong>Toque em Iniciar desbloqueio.</strong> O host externo aparece em uma janela. Siga as instruções do host; ele pode exigir outro toque para iniciar.</li><li><strong>Aguarde o resultado real.</strong> A barra RGB indica atividade. Confira a mensagem do host e a presença do GoldHEN no console para confirmar o resultado.</li></ol><p class="notice-box">A 14.00 está indisponível. O nome de uma faixa não garante suporte a todas as versões intermediárias. Tentativas de exploit podem falhar ou reiniciar o console.</p><h3>Para hospedar na sua rede</h3><p>Baixe o projeto no rodapé e extraia o ZIP no computador. Abra um terminal na pasta extraída e execute:</p><code>python serve.py --port 8000</code><p>Conecte PS4 e computador à mesma rede e abra no PS4 o endereço HTTP exibido. Os hosts de exploit continuam precisando de acesso à internet na primeira abertura.</p>';
  var payloadGuide='<p>Os hosts integrados oferecem seus próprios payloads. Para usar seu arquivo, você precisa de um <strong>BinLoader já ativo no PS4</strong> e de um computador na mesma rede.</p><ol><li>Baixe seu <code>goldhen.bin</code> de uma fonte confiável e confira se a versão do payload corresponde ao firmware.</li><li>Abra o BinLoader do host e confira a porta indicada. O servidor BinLoader do GoldHEN costuma usar <strong>9090</strong>; alguns hosts usam outra porta.</li><li>Baixe o enviador Python, mantenha seu arquivo na mesma pasta e execute no computador:</li></ol><code>python send_payload.py 192.168.1.50 goldhen.bin --port 9090</code><p>Troque o IP e a porta pelos exibidos no seu console. O script envia os bytes via TCP e informa o resultado da transferência. A confirmação da execução aparece no PS4.</p><p class="notice-box">Selecionar um .bin nesta página apenas confere extensão, tamanho e, quando disponível, SHA-256. Isso não valida autenticidade, compatibilidade nem injeta o arquivo. O navegador não envia TCP diretamente ao console.</p><p><a href="tools/send_payload.py" download>Baixar send_payload.py</a> · <a href="https://github.com/GoldHEN/GoldHEN/releases" target="_blank" rel="noopener noreferrer">Releases oficiais do GoldHEN</a></p>';
  function showInfo(title,body,kicker){$('modal-title').textContent=title;$('modal-kicker').textContent=kicker||'ALEXGOLDHEN';$('modal-content').innerHTML=body;openModal('info-modal');}
  each('[data-open-guide]',function(el){el.addEventListener('click',function(){showInfo('Pronto para começar?',guide,'GUIA RÁPIDO');});});
  $('payload-instructions').addEventListener('click',function(){showInfo('Envie seu goldhen.bin',payloadGuide,'PAYLOAD LOCAL');});
  each('[data-open-compat]',function(el){el.addEventListener('click',function(){
    var rows='';for(var i=0;i<keys.length;i++){var engine=Core.catalog[keys[i]];rows+='<tr><td>'+engine.name+'</td><td>'+engine.versions.join(' · ')+'</td></tr>';}
    showInfo('Cada firmware tem sua rota.','<p>Versões cadastradas nesta central, conforme as tabelas dos hosts consultados em 01/11/2026.</p><table><thead><tr><th>Rota</th><th>Versões selecionáveis</th></tr></thead><tbody>'+rows+'<tr><td>Firmware 14.00</td><td>Indisponível — execução bloqueada.</td></tr></tbody></table><p>WebKIT reúne hosts legados, PSFree/Lapse e CSSFontFace. SlopKIT Base abre o host Lapse/Poops; Relapse abre o host para 13.02–13.52.</p><p>Os nomes, compatibilidade, payloads e resultados dependem de cada implementação externa. Esta central não foi validada em um console físico.</p><p><a href="https://github.com/eddieygaming/ps4aio" target="_blank" rel="noopener noreferrer">Ver código e compatibilidade do host</a></p>','COMPATIBILIDADE');
  });});
  each('[data-open-credits]',function(el){el.addEventListener('click',function(){showInfo('Construído com a comunidade.','<p><strong>Identidade visual:</strong> AlexGoldHEN e OnyxAI, imagens fornecidas por Alexandre Games / AlexSTORE.</p><p><strong>OnyxAI:</strong> detecção determinística e local do user-agent. O detector não usa modelo de IA nem envia dados para um servidor.</p><p><strong>Execução:</strong> esta central encaminha para os hosts externos de <a href="https://github.com/eddieygaming/ps4aio" target="_blank" rel="noopener noreferrer">eddieygaming/ps4aio</a>. O código de exploit e os binários pertencem aos autores dos respectivos projetos e não são redistribuídos aqui.</p><p><strong>GoldHEN:</strong> projeto de SiSTRo e colaboradores. <a href="https://github.com/GoldHEN/GoldHEN" target="_blank" rel="noopener noreferrer">Repositório oficial</a>.</p><p><strong>Pesquisa da comunidade:</strong> SLOPKIT/Jordy, PSFree, Lapse, Netctrl/Poops e Relapse. Créditos completos estão nos repositórios dos hosts.</p><p class="small-copy">Interface: HTML, CSS e JavaScript. Ferramentas locais: Python 3. Nenhuma afiliação à Sony Interactive Entertainment. Compatibilidade consultada em 01/11/2026.</p>','FONTES E CRÉDITOS');});});
  function launch(engine){
    var validation=Core.validateLaunch(device,automatic,engine,$('firmware-'+engine).value);
    if(!validation.ok){message(validation.reason);return;}
    if(running){return;}
    var info=Core.catalog[engine],route=validation.route;
    running=engine;$('card-'+engine).classList.add('is-running');
    $('run-title').textContent=info.name+' · PS4 '+route.firmware;
    $('run-status').style.color=info.color;$('run-message').textContent=info.message;$('run-estimate').textContent=info.estimate;
    $('direct-host').href=route.url;$('run-elapsed').textContent='00:00';
    var frame=document.createElement('iframe');frame.className='host-frame';frame.title='Host de exploit '+info.name+' para PS4 '+route.firmware;frame.setAttribute('referrerpolicy','no-referrer');frame.src=route.url;$('host-container').appendChild(frame);
    var started=Date.now();elapsedTimer=setInterval(function(){var seconds=Math.floor((Date.now()-started)/1000),minutes=Math.floor(seconds/60);$('run-elapsed').textContent=(minutes<10?'0':'')+minutes+':'+(seconds%60<10?'0':'')+seconds%60;},1000);
    openModal('run-modal');update();
  }
  each('[data-launch]',function(button){button.addEventListener('click',function(){launch(button.getAttribute('data-launch'));});});
  function fileFeedback(text,type){$('file-feedback').textContent=text;$('file-feedback').className='file-feedback'+(type?' '+type:'');}
  function inspectFile(file){
    var revision=++fileRevision,check=Core.validateFile(file);
    if(!check.ok){$('file-title').textContent='Adicione seu goldhen.bin';$('file-subtitle').textContent='Arraste o arquivo ou clique para selecionar';$('payload-file').value='';fileFeedback(check.reason,'error');return;}
    $('file-title').textContent=file.name;$('file-subtitle').textContent=(file.size/1024).toFixed(1)+' KB · arquivo local, sem upload';
    fileFeedback('Formato e tamanho conferidos. Compatibilidade e autenticidade não verificadas.','success');
    if(window.FileReader&&window.crypto&&window.crypto.subtle){
      var reader=new FileReader();reader.onload=function(){
        if(revision!==fileRevision){return;}
        window.crypto.subtle.digest('SHA-256',reader.result).then(function(hash){
          if(revision!==fileRevision){return;}
          var bytes=new Uint8Array(hash),hex='';for(var i=0;i<bytes.length;i++){hex+=('0'+bytes[i].toString(16)).slice(-2);}
          fileFeedback('SHA-256: '+hex+'. Use o enviador local para transferir o arquivo.','success');
        },function(){if(revision===fileRevision){fileFeedback('Formato e tamanho conferidos. SHA-256 indisponível neste navegador.','success');}});
      };reader.onerror=function(){if(revision===fileRevision){fileFeedback('Não foi possível ler o arquivo. Selecione novamente.','error');}};reader.readAsArrayBuffer(file);
    }
  }
  $('payload-file').addEventListener('change',function(){if(this.files&&this.files.length){inspectFile(this.files[0]);}});
  var zone=$('drop-zone');zone.addEventListener('dragover',function(event){event.preventDefault();zone.classList.add('dragging');});zone.addEventListener('dragleave',function(){zone.classList.remove('dragging');});zone.addEventListener('drop',function(event){event.preventDefault();zone.classList.remove('dragging');if(event.dataTransfer&&event.dataTransfer.files.length){inspectFile(event.dataTransfer.files[0]);}});
  // Keep file selection reachable when navigating with a controller/keyboard.
  $('payload-file').addEventListener('focus',function(){zone.style.outline='2px solid #e6b754';zone.style.outlineOffset='4px';});$('payload-file').addEventListener('blur',function(){zone.style.outline='';});
  each('.nav-item[href]',function(link){link.addEventListener('click',function(){each('.nav-item',function(item){item.classList.remove('active');});link.classList.add('active');});});
  if(location.protocol==='file:'||location.hostname==='localhost'||/^\d+\.\d+\.\d+\.\d+$/.test(location.hostname)){
    each('[data-project-download]',function(link){visible(link,false);});
  }
  update();
}());
