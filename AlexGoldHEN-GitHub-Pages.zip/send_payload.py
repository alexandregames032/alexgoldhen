#!/usr/bin/env python3
"""Send a local .bin to an already running PS4 BinLoader on a LAN."""
import argparse
import hashlib
import ipaddress
from pathlib import Path
import socket
import sys


def validate_target(value):
    try:
        address = ipaddress.IPv4Address(value)
    except ipaddress.AddressValueError as error:
        raise argparse.ArgumentTypeError("Informe o endereço IPv4 do PS4.") from error
    if not any(address in net for net in (
        ipaddress.IPv4Network("10.0.0.0/8"),
        ipaddress.IPv4Network("172.16.0.0/12"),
        ipaddress.IPv4Network("192.168.0.0/16"),
    )):
        raise argparse.ArgumentTypeError("Use o IPv4 privado do PS4 na sua rede local.")
    return str(address)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("ip", type=validate_target, help="IPv4 local do PS4")
    parser.add_argument("payload", type=Path, help="Caminho de goldhen.bin")
    parser.add_argument("--port", type=int, default=9090, help="Porta do BinLoader (padrão: 9090)")
    args = parser.parse_args()
    if not 1 <= args.port <= 65535:
        parser.error("A porta deve estar entre 1 e 65535.")
    if args.payload.suffix.lower() != ".bin":
        parser.error("O payload deve ser um arquivo .bin.")
    try:
        if not args.payload.is_file():
            parser.error("Arquivo não encontrado.")
        if not 0 < args.payload.stat().st_size <= 16 * 1024 * 1024:
            parser.error("O arquivo precisa ter entre 1 byte e 16 MB.")
        data = args.payload.read_bytes()
        print(f"Arquivo: {args.payload.name} ({len(data)} bytes)")
        print(f"SHA-256: {hashlib.sha256(data).hexdigest()}")
        print(f"Enviando para {args.ip}:{args.port}...")
        with socket.create_connection((args.ip, args.port), timeout=15) as connection:
            connection.settimeout(15)
            connection.sendall(data)
            connection.shutdown(socket.SHUT_WR)
        print("Bytes enviados. Confira no PS4 se o payload foi executado.")
        return 0
    except (OSError, socket.timeout) as error:
        print(f"Falha na transferência: {error}. Confira IP, porta e BinLoader ativo.", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
