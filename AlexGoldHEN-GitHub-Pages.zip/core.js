/* OnyxAI: deterministic, local browser identification. No remote AI service. */
(function(root,factory){
  if(typeof module==='object'&&module.exports){module.exports=factory();}
  else{root.OnyxCore=factory();}
}(this,function(){
  'use strict';
  var HOST='https://eddieygaming.github.io/ps4aio/';
  var catalog={
    webkit:{name:'WebKIT',versions:['5.05','6.00','6.02','6.10','6.20','6.50','6.51','6.70','6.71','6.72','7.00','7.01','7.02','7.50','7.51','7.55','8.00','8.01','8.03','8.50','8.52','9.00','9.03','9.04','9.50','9.51','9.60','10.00','10.01'],color:'#71a8ff',message:'WebKIT detectado com sucesso. Fazendo o desbloqueio.',estimate:'Isso normalmente leva até 0:07:45. Estimativa; o tempo pode variar.'},
    base:{name:'SlopKIT Base',versions:['11.00','11.50','11.52','12.00','12.02','12.50','12.52','13.00'],color:'#5bdba6',message:'SlopKIT BASE DETECTADO COM SUCESSO. Fazendo o desbloqueio.',estimate:'Isso normalmente leva um pouco menos de 3 min. Estimativa; o tempo pode variar.'},
    relapse:{name:'SlopKIT Relapse',versions:['13.02','13.04','13.50','13.52'],color:'#b78bff',message:'SlopKIT RELAPSE DETECTADO COM SUCESSO. Fazendo o desbloqueio.',estimate:'Isso normalmente leva até uns 30 s. Estimativa; o tempo pode variar.'}
  };
  function firmwareNumber(version){
    var m=/^(\d{1,2})\.(\d{2})$/.exec(String(version));
    return m?parseInt(m[1],10)*100+parseInt(m[2],10):null;
  }
  function engineFor(version){
    var keys=['webkit','base','relapse'];
    for(var i=0;i<keys.length;i++){if(catalog[keys[i]].versions.indexOf(version)!==-1){return keys[i];}}
    return null;
  }
  function detect(ua){
    ua=String(ua||'');
    var isPS4=/PlayStation\s+4(?:[\/\s;)])/i.test(ua)&&!/PlayStation\s+5/i.test(ua);
    // Keep the firmware's two decimal components verbatim: 9.60 is not 9.06.
    var match=isPS4?/PlayStation\s+4[\/\s]+(\d{1,2})\.(\d{2})(?!\d)/i.exec(ua):null;
    var fw=match?parseInt(match[1],10)+'.'+match[2]:null;
    var label=isPS4?'PlayStation 4':/PlayStation\s+5/i.test(ua)?'PlayStation 5':/Android/i.test(ua)?'Android':/iPhone|iPad|iPod/i.test(ua)?'iPhone / iPad':/Windows/i.test(ua)?'Computador · Windows':/Macintosh|Mac OS X/i.test(ua)?'Computador · Mac':'Navegador do computador';
    return{isPS4:isPS4,firmware:fw,engine:engineFor(fw),device:label};
  }
  function routeFor(version){
    var engine=engineFor(version),n=firmwareNumber(version);
    if(!engine){return null;}
    var path;
    if(version==='5.05'){path='505/index.html';}
    else if(version==='6.72'){path='672/index.html';}
    else if(n>=700&&n<=852){path='700/cache.html';}
    else if(n>=900&&n<=960){path='900/cache.html';}
    else if(engine==='webkit'){path='css/latest/index.html';}
    else if(engine==='base'){path='slopkit/latest/index.html';}
    else{path='relapse/goldhen/index.html';}
    return{engine:engine,url:HOST+path,firmware:version};
  }
  function validateLaunch(device,automatic,engine,selected){
    if(!catalog[engine]){return{ok:false,reason:'Rota desconhecida.'};}
    var version=automatic?device.firmware:selected;
    if(!automatic&&!version){return{ok:false,reason:'Selecione seu firmware.'};}
    if(!device.isPS4){return{ok:false,reason:'Abra no navegador do PS4.'};}
    if(!device.firmware){return{ok:false,reason:'Não foi possível confirmar o firmware.'};}
    if(version!==device.firmware){return{ok:false,reason:'A versão selecionada não corresponde ao PS4.'};}
    var route=routeFor(version);
    if(!route||route.engine!==engine){return{ok:false,reason:version==='14.00'?'14.00 ainda indisponível.':'Sem rota para este firmware.'};}
    return{ok:true,route:route};
  }
  function validateFile(file){
    if(!file||!file.name||!/\.bin$/i.test(file.name)){return{ok:false,reason:'Selecione um arquivo com extensão .bin.'};}
    if(file.size===0){return{ok:false,reason:'O arquivo está vazio.'};}
    if(file.size>16*1024*1024){return{ok:false,reason:'O arquivo excede o limite de 16 MB.'};}
    return{ok:true};
  }
  return{catalog:catalog,detect:detect,engineFor:engineFor,routeFor:routeFor,firmwareNumber:firmwareNumber,validateLaunch:validateLaunch,validateFile:validateFile};
}));
