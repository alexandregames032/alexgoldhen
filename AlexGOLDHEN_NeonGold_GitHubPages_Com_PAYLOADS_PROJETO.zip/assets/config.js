// AlexGOLDHEN / ES5 / PS4 browser — replaced in integrated build.
window.ALEX_HOST_READY = false;
