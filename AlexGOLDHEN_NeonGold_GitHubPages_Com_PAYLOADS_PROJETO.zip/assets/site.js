/* AlexGOLDHEN: ES5-compatible portal controller for PS4 WebKit, no external JS libraries. */
(function () {
  'use strict';
  var KEY = 'alexgoldhen.portal.';
  var routes = [
    {name:'BPF Double Free',lo:4.50,hi:5.07,index:0},
    {name:'Bad Hoist',lo:6.70,hi:6.72,index:1},
    {name:'PSFree / Lapse',lo:7.00,hi:9.60,index:2},
    {name:'CSSFontFace / Netctrl',lo:9.00,hi:11.02,index:3},
    {name:'Slopkit / Lapse',lo:10.00,hi:12.02,index:4},
    {name:'Slopkit / Netctrl',lo:12.50,hi:13.00,index:5},
    {name:'Slopkit / Relapse',lo:12.50,hi:13.52,index:6},
    {name:'Slopkit / Afterglow',lo:14.02,hi:14.02,index:7}
  ];
  var translations = {
    pt:{unknown:'Não identificado',nonPS4:'Navegador não PS4',integrated:'INTEGRADO',external:'EXTERNO',detected:'Firmware identificado pelo navegador',manual:'Firmware selecionado manualmente',unsupported:'Nenhuma rota documentada para esta versão',supported:'Rota documentada na base WebKitty',selectFw:'Selecione um firmware para consultar compatibilidade.',none:'Não detectado',used:'Payload preferido: ',copied:'SHA-256 copiado.',reset:'Preferências redefinidas.',needsBuild:'O site estático permite baixar os arquivos. O uso no host integrado exige o build completo pelo GitHub Actions.',externalOpen:'Abrindo o host WebKitty original. Os arquivos pessoais não são transmitidos para o site externo.'},
    en:{unknown:'Not identified',nonPS4:'Non-PS4 browser',integrated:'INTEGRATED',external:'EXTERNAL',detected:'Firmware detected in the browser',manual:'Firmware manually selected',unsupported:'No documented chain for this version',supported:'Chain documented in WebKitty',selectFw:'Select firmware to check compatibility.',none:'Not detected',used:'Preferred payload: ',copied:'SHA-256 copied.',reset:'Preferences reset.',needsBuild:'The static site allows downloads. Using files in the integrated host requires the full GitHub Actions build.',externalOpen:'Opening the original WebKitty host. Personal files are not sent to the external site.'},
    es:{unknown:'No identificado',nonPS4:'Navegador no PS4',integrated:'INTEGRADO',external:'EXTERNO',detected:'Firmware detectado por el navegador',manual:'Firmware seleccionado manualmente',unsupported:'Sin ruta documentada para esta versión',supported:'Ruta documentada en WebKitty',selectFw:'Selecciona un firmware para comprobar compatibilidad.',none:'No detectado',used:'Payload preferido: ',copied:'SHA-256 copiado.',reset:'Preferencias restablecidas.',needsBuild:'La página estática permite descargar archivos. Para usarlos en el host integrado ejecuta la compilación completa.',externalOpen:'Abriendo el host WebKitty original. Tus archivos no se envían al sitio externo.'}
  };
  var lookup = {};
  var payloads = window.ALEX_PAYLOADS || [];
  for (var i=0;i<payloads.length;i++) lookup[payloads[i].id] = payloads[i];
  function $(id){return document.getElementById(id);}
  function get(key,other){try{var v=localStorage.getItem(KEY+key);return v===null?other:v;}catch(e){return other;}}
  function set(key,value){try{localStorage.setItem(KEY+key,value);}catch(e){}}
  function clean(){try{var keys=[],k,i;for(i=0;i<localStorage.length;i++){k=localStorage.key(i);if(k&&k.indexOf(KEY)===0)keys.push(k);}for(i=0;i<keys.length;i++)localStorage.removeItem(keys[i]);}catch(e){}}
  function language(){var l=get('language','pt');return translations[l]?l:'pt';}
  function say(key){return translations[language()][key] || translations.pt[key] || key;}
  function firmwareFromUA(){var ua=navigator.userAgent||'';var m=ua.match(/(?:PlayStation\s*4|\bPS4\b)[^\d]{0,50}(\d{1,2}\.\d{2})/i);return m?m[1]:null;}
  function isPS4(){return /PlayStation\s*4|\bPS4\b/i.test(navigator.userAgent||'');}
  function chooseRoute(firmware){var n=parseFloat(firmware),selected=null;if(!firmware||isNaN(n))return null;for(var i=0;i<routes.length;i++){var r=routes[i];if(n+0.0001>=r.lo&&n-0.0001<=r.hi)selected=r;}return selected;}
  function notify(message){var el=$('toast');el.textContent=message;el.className='toast show';clearTimeout(window.alexToastTimer);window.alexToastTimer=setTimeout(function(){el.className='toast';},4400);}
  function label(id,str){var el=$(id);if(el)el.textContent=str;}
  function updateCompatibility(){
    var uaFw=firmwareFromUA();var chosen=$('firmwareSelect').value;var fw=chosen==='auto'?uaFw:chosen;var route=chooseRoute(fw);
    label('deviceName',isPS4()?'PlayStation 4':say('nonPS4'));
    label('firmwareName',uaFw||say('none'));label('systemVersion',uaFw||say('none'));
    label('browserName',isPS4()?'PS4 WebKit':(navigator.userAgent||'Navegador web').split(' ').slice(0,4).join(' '));
    label('diagnosisTitle',fw?'Firmware '+fw:say('unknown'));
    label('diagnosisInfo', !fw ? say('selectFw') : (chosen==='auto' ? say('detected') : say('manual')));
    label('chainName',route?route.name:'—');label('analysisStatus',!fw?'—':route?say('supported'):say('unsupported'));
    var rows=document.querySelectorAll('[data-route-row]');for(var i=0;i<rows.length;i++){
      var row=rows[i];row.className='matrix-row'+(route&&+row.getAttribute('data-route-row')===route.index?' active':'');
      var em=row.querySelector('em');if(em)em.textContent=(route&&+row.getAttribute('data-route-row')===route.index)?'ROTA IDENTIFICADA':'DISPONÍVEL NA BASE';
    }
  }
  function selectedPayload(){var id=get('payload','goldhen');return lookup[id]?id:'goldhen';}
  function refreshSelection(){var id=selectedPayload();var cards=document.querySelectorAll('[data-payload-card]');for(var i=0;i<cards.length;i++)cards[i].className='payload-card glass'+(cards[i].getAttribute('data-payload-card')===id?' selected':'');label('selectedPayloadLabel',lookup[id]?lookup[id].label:'GoldHEN');}
  function usePayload(id){if(!lookup[id])return;set('payload',id);refreshSelection();notify(say('used')+lookup[id].label);launchHost(id);}
  function launchHost(id){
    id=id||selectedPayload();
    if(window.ALEX_HOST_READY === true){window.location.href='host/index.html?alexPayload='+encodeURIComponent(id);return;}
    notify(say('externalOpen'));
    // The upstream host is external; uploaded local binaries remain solely on this host.
    setTimeout(function(){window.location.href='https://webkitty.arabpixel.net/';},720);
  }
  function refreshHost(){var ready=window.ALEX_HOST_READY===true;label('hostState',ready?say('integrated'):say('external'));label('integrationStatus',ready?say('integrated'):say('external'));label('heroHostStatus',ready?'WEBKITTY INTEGRADO':'BUILD PRONTO PARA PUBLICAÇÃO');label('topStatus',ready?'HOST INTEGRADO':'PORTAL PS4');}
  function theme(id){
    var colors={gold:['#ffd56d','#c79c3f','#fff2b9','255,213,109'],amber:['#ff9a42','#c26d2b','#ffdeb9','255,154,66'],emerald:['#b5ff79','#649e37','#edffc9','181,255,121'],ice:['#7bdfff','#397eaf','#c4f2ff','123,223,255']};
    if(!colors[id])id='gold';var values=colors[id];var st=document.documentElement.style;
    st.setProperty('--accent',values[0]);st.setProperty('--accent-soft',values[1]);st.setProperty('--accent-bright',values[2]);st.setProperty('--accent-rgb',values[3]);
    var chips=document.querySelectorAll('[data-color]');for(var i=0;i<chips.length;i++)chips[i].className='color-chip'+(chips[i].getAttribute('data-color')===id?' active':'');set('color',id);
  }
  function motion(){document.body.className=( $('motionSwitch').checked?'':'no-motion ' ) + ($('glassSwitch').checked?'':'no-glass');set('motion',$('motionSwitch').checked?'1':'0');set('glass',$('glassSwitch').checked?'1':'0');}
  function copyHash(id){if(!lookup[id])return;var sha=lookup[id].sha256;var box=document.createElement('textarea');box.value=sha;box.style.position='fixed';box.style.left='-9999px';document.body.appendChild(box);box.select();try{document.execCommand('copy');notify(say('copied'));}catch(e){notify(sha);}document.body.removeChild(box);}
  function fillPayloads(){for(var i=0;i<payloads.length;i++){var p=payloads[i];var size=(p.size/1024).toFixed(1).replace('.',',')+' KB';label(p.id+'Size',size);label(p.id+'Hash',p.sha256.substring(0,32)+'…');}label('payloadCount',payloads.length+' arquivos locais');refreshSelection();}
  function closeMenu(){var nav=$('primaryNav');nav.className='nav';$('menuBtn').setAttribute('aria-expanded','false');}
  function init(){
    var selected=$('firmwareSelect');var savedFw=get('firmware','auto');selected.value=savedFw;if(selected.value!==savedFw)selected.value='auto';
    selected.addEventListener('change',function(){set('firmware',selected.value);updateCompatibility();});
    theme(get('color','gold'));
    $('languageSelect').value=language();$('languageSelect').addEventListener('change',function(){set('language',this.value);document.documentElement.lang=this.value==='pt'?'pt-BR':this.value;updateCompatibility();refreshHost();});
    $('motionSwitch').checked=get('motion','1')==='1';$('glassSwitch').checked=get('glass','1')==='1';motion();
    $('motionSwitch').addEventListener('change',motion);$('glassSwitch').addEventListener('change',motion);
    var chips=document.querySelectorAll('[data-color]');for(var i=0;i<chips.length;i++)chips[i].addEventListener('click',function(){theme(this.getAttribute('data-color'));});
    var uses=document.querySelectorAll('[data-use-payload]');for(var j=0;j<uses.length;j++)uses[j].addEventListener('click',function(){usePayload(this.getAttribute('data-use-payload'));});
    var copy=document.querySelectorAll('[data-copy-hash]');for(var k=0;k<copy.length;k++)copy[k].addEventListener('click',function(){copyHash(this.getAttribute('data-copy-hash'));});
    ['launchBtn','analyzerLaunch','closingHost'].forEach(function(id){$(id).addEventListener('click',function(){launchHost();});});
    $('resetButton').addEventListener('click',function(){clean();selected.value='auto';$('languageSelect').value='pt';$('motionSwitch').checked=true;$('glassSwitch').checked=true;theme('gold');motion();refreshSelection();updateCompatibility();notify(say('reset'));});
    $('menuBtn').addEventListener('click',function(){var nav=$('primaryNav');var next=nav.className==='nav'?'nav open':'nav';nav.className=next;this.setAttribute('aria-expanded',next==='nav open'?'true':'false');});
    var links=document.querySelectorAll('.nav-link');for(var n=0;n<links.length;n++)links[n].addEventListener('click',function(){closeMenu();for(var j=0;j<links.length;j++)links[j].className='nav-link';this.className='nav-link active';});
    updateCompatibility();refreshHost();fillPayloads();
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
