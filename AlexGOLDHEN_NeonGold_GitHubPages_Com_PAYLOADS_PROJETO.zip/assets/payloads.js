/* Generated from user-supplied files. Never auto-executes binaries. */
window.ALEX_PAYLOADS = [
  {
    "id": "goldhen",
    "label": "GoldHEN",
    "file": "goldhen.bin",
    "size": 293120,
    "sha256": "df3f27c1b35bc7c40e3a08caab948930914dc7d0301a73b68945cf6ffe40ea12",
    "url": "goldhen.bin"
  },
  {
    "id": "hen",
    "label": "PS4 HEN",
    "file": "hen.bin",
    "size": 230652,
    "sha256": "6871c4839cd74cf6a69fb739a7c726693f3cc7ea5b7a5dc1690b60e07146aca8",
    "url": "hen.bin"
  }
];
