# AlexGOLDHEN — Neon Gold Liquid Glass · Site PS4

![Identidade AlexGOLDHEN](assets/alexgoldhen.png)

Projeto para publicação no GitHub Pages, desenvolvido a partir do pacote fornecido pelo proprietário da marca. **Contém os dois arquivos binários originais enviados pelo usuário** e a interface em HTML, CSS e JavaScript ES5.

## Conteúdo do pacote

| Caminho | Finalidade |
|---|---|
| `index.html` | Portal AlexGOLDHEN para PS4, desktop e celular |
| `assets/site.css` | Neon Gold, Liquid Glass, componentes adaptáveis, modo desempenho |
| `assets/site.js` | Detecção de firmware, preferências, seleção de payloads |
| `assets/payloads.js` | Manifesto para a interface (SHA-256 e tamanho de cada arquivo) |
| `goldhen.bin` | Arquivo enviado pelo usuário: 293.120 bytes |
| `hen.bin` | Arquivo enviado pelo usuário: 230.652 bytes |
| `payloads.json` | Manifesto verificável dos binários |
| `integrations/*` | Personalização do host WebKitty e seleção de payload por URL |
| `tools/build_full.py` | Incorpora a árvore WebKitty ao portal e copia os dois arquivos |
| `tools/check_site.py` | Verifica os arquivos, hashes e integração local |
| `.github/workflows/build-publish.yml` | Compila e publica automaticamente pelo GitHub Actions |

### Integridade dos binários fornecidos

- `goldhen.bin`: SHA-256 `df3f27c1b35bc7c40e3a08caab948930914dc7d0301a73b68945cf6ffe40ea12`
- `hen.bin`: SHA-256 `6871c4839cd74cf6a69fb739a7c726693f3cc7ea5b7a5dc1690b60e07146aca8`

Os hashes representam **integridade**, não autenticidade ou compatibilidade do payload com um firmware específico. Nenhum PS4 físico foi usado nos testes.

## Publicação pelo GitHub Pages

1. Extraia **todo o conteúdo do ZIP do projeto** e envie os arquivos para a raiz da branch `main` do repositório GitHub que hospedará a loja. Não deixe a pasta externa do ZIP como nível adicional. A pasta oculta `.github` deve ser enviada junto.
2. Em **Settings → Pages → Build and deployment**, selecione **GitHub Actions**.
3. Em **Actions**, selecione o fluxo **AlexGOLDHEN | Build Full Website** e use **Run workflow**. O push em `main` também dispara o fluxo.
4. O fluxo baixa o repositório original WebKitty, incorpora o tema AlexGOLDHEN, copia os dois payloads para o host, valida os hashes e publica o site. O ZIP final também fica disponível como artefato **AlexGOLDHEN_SITE_COMPLETO**.

O diretório **`dist/`** produzido pelo fluxo é o site estático publicável; ele não requer servidor Node/Python em produção.

### Endereço de publicação

Para o repositório conectado `alexandregames032/alexgoldhen`, a URL padrão do GitHub Pages para um projeto é **`https://alexandregames032.github.io/alexgoldhen/`**, desde que Pages esteja habilitado.

**`https://alexgoldhen.github.io/` é outra URL.** Ela só é disponibilizada no GitHub Pages se pertencer à conta `alexgoldhen` com o repositório de usuário `alexgoldhen.github.io`. Publicar no repositório `alexandregames032/alexgoldhen` **não** cria automaticamente esse endereço.

Não foi feita publicação remota nesta entrega.

## Como construir localmente

Requer **Python 3.9+**, **Git** e conexão à internet para o clone do WebKitty.

```bash
python tools/build_full.py --target dist
python tools/check_site.py dist
```

O site gerado terá a estrutura:

```text
dist/
  index.html                         # portal de apresentação e controle
  assets/                            # identidade, scripts, estilos e manifestos
  goldhen.bin                        # seu arquivo original
  hen.bin                            # seu arquivo original
  payloads.json
  host/index.html                    # host WebKitty com identidade AlexGOLDHEN
  host/includes/payloads/HEN/
    alexgoldhen-goldhen.bin          # cópia byte a byte de goldhen.bin
    alexgoldhen-hen.bin              # cópia byte a byte de hen.bin
  host/includes/js/alexgoldhen-payload-choice.js
  host/LICENSE                      # licença upstream
  host/README.md                    # créditos upstream
  SOURCE.md                         # detalhes de fontes
```

Para testar sem internet, apenas a interface e os downloads dos payloads:

```bash
python tools/build_full.py --skip-host --target dist
python tools/check_site.py dist
python -m http.server 8080 --directory dist
```

Para integrar um clone WebKitty já existente:

```bash
python tools/build_full.py --upstream-dir /pasta/WebKitty --target dist
```

### Como o seletor de payload funciona

Na página AlexGOLDHEN, clique **Selecionar e abrir** no arquivo desejado. No site integrado, a página abre `host/index.html?alexPayload=goldhen` ou `?alexPayload=hen`. O pequeno módulo de integração define a chave de sessão `payload_path` do WebKitty para a **cópia correspondente**. Isso não executa o binário sozinho: o funcionamento do exploit é controlado pelo host original e pelo console.

Se a página inicial estiver publicada sem o diretório `host/`, o botão de host aponta para a hospedagem original do WebKitty; os arquivos incluídos neste ZIP **não** serão enviados ao servidor externo. Para usar os payloads personalizados é indispensável publicar o **build integrado** gerado pelo fluxo.

## Origem, limitações e licença

- Interface personalizada: AlexGOLDHEN, neon amarelo/dourado, estilo Liquid Glass interpretado em CSS (não usa bibliotecas oficiais do iOS).
- Base de host: [WebKitty / ArabPixel](https://github.com/ArabPixel/WebKitty), sob **AGPL-3.0-or-later**. O código, a licença e os créditos do upstream são mantidos no site integrado.
- A tabela de compatibilidade é informativa e usa as cadeias documentadas pelo projeto WebKitty. A presença de um firmware na tabela não garante êxito.
- O portal não descobre automaticamente o IP de rede privado do PS4 a partir de um navegador comum, nem simula instalação bem-sucedida.
- Foram testados: sintaxe dos scripts locais, integridade SHA-256 dos payloads, estrutura dos ZIPs, build com um mock de host upstream e interface Chromium em desktop e mobile. **A compilação a partir do WebKitty real e o funcionamento em PS4 não puderam ser testados offline.**
