#!/usr/bin/env python3
"""Validate AlexGOLDHEN output and uploaded payload SHA-256. Does not verify exploit execution."""
from __future__ import annotations
import hashlib
import json
import sys
from pathlib import Path

root = Path(sys.argv[1] if len(sys.argv) > 1 else '.').resolve()
required = [
    'index.html', 'assets/site.css', 'assets/site.js', 'assets/payloads.js',
    'assets/alexgoldhen.png', 'assets/config.js', 'goldhen.bin', 'hen.bin', 'payloads.json'
]
missing = [name for name in required if not (root / name).is_file()]
if missing:
    raise SystemExit('Arquivos ausentes: ' + ', '.join(missing))

page = (root / 'index.html').read_text('utf-8')
if not all(item in page for item in ['AlexGOLDHEN', 'firmwareSelect', 'data-use-payload="goldhen"', 'data-use-payload="hen"']):
    raise SystemExit('A página inicial não contém os recursos exigidos.')

payloads = json.loads((root / 'payloads.json').read_text('utf-8'))
assert {p['id'] for p in payloads} == {'goldhen', 'hen'}, 'Manifesto incompleto'
for entry in payloads:
    original = root / entry['file']
    raw = original.read_bytes()
    if len(raw) != entry['size']:
        raise SystemExit('Tamanho diferente para ' + entry['file'])
    if hashlib.sha256(raw).hexdigest() != entry['sha256']:
        raise SystemExit('SHA-256 divergente para ' + entry['file'])
    if (root / 'host').exists():
        installed = root / 'host/includes/payloads/HEN' / ('alexgoldhen-' + entry['id'] + '.bin')
        if not installed.is_file() or installed.read_bytes() != raw:
            raise SystemExit('Host perdeu o payload: ' + entry['file'])

if (root / 'host').exists():
    required_host = [
        'host/index.html', 'host/includes/js/firmware.js', 'host/includes/js/jailbreak.js',
        'host/LICENSE', 'host/includes/css/colors/alexgoldhen.css',
        'host/includes/js/alexgoldhen-payload-choice.js',
        'host/includes/assets/branding/alexgoldhen.png'
    ]
    missing = [name for name in required_host if not (root / name).is_file()]
    if missing:
        raise SystemExit('Host WebKitty incompleto: ' + ', '.join(missing))
    text = (root / 'host/index.html').read_text('utf-8')
    if 'alexgoldhen-payload-choice.js' not in text:
        raise SystemExit('O seletor de payload não está carregado no WebKitty.')
    print('PASS: Site, licença upstream, scripts e payloads incorporados. Teste real no PS4 pendente.')
else:
    print('PASS: Site estático com goldhen.bin, hen.bin e manifestos verificados. Host upstream ainda não integrado.')
