#!/usr/bin/env python3
"""AlexGOLDHEN static site build: fetch WebKitty and apply visual branding; Python 3.9+."""
from __future__ import annotations
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
REPO = 'https://github.com/ArabPixel/WebKitty.git'
EXCLUDED = {'.git', '.github', 'tools', 'integrations', '__pycache__', 'dist', 'site'}

def uploaded_payloads():
    items = []
    for ident, label in [('goldhen', 'GoldHEN'), ('hen', 'PS4 HEN')]:
        file = ROOT / (ident + '.bin')
        if not file.is_file() or file.stat().st_size < 1024:
            raise RuntimeError('Payload obrigatório ausente ou inválido: ' + str(file))
        items.append({
            'id': ident,
            'label': label,
            'file': file.name,
            'url': file.name,
            'size': file.stat().st_size,
            'sha256': hashlib.sha256(file.read_bytes()).hexdigest(),
        })
    return items


def write_payload_manifest(dest: Path, items):
    (dest / 'assets').mkdir(parents=True, exist_ok=True)
    (dest / 'payloads.json').write_text(json.dumps(items, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    (dest / 'assets/payloads.js').write_text(
        '/* Generated from the actual .bin files at build time. */\nwindow.ALEX_PAYLOADS = ' +
        json.dumps(items, ensure_ascii=False, indent=2) + ';\n', encoding='utf-8')


def copy_portal(dest: Path):
    dest.mkdir(parents=True, exist_ok=True)
    for child in ROOT.iterdir():
        if child.name in EXCLUDED or child.name.startswith('AlexGOLDHEN_SITE_PUBLICAR'):
            continue
        if child.name in {'README.md', 'LICENSE-OVERLAY.md'}:
            continue
        out = dest / child.name
        if child.is_dir():
            shutil.copytree(child, out, dirs_exist_ok=True)
        elif child.is_file():
            shutil.copy2(child, out)


def patch_host(host: Path):
    index = host / 'index.html'
    initial = host / 'includes' / 'js' / 'initial.js'
    if not index.is_file() or not initial.is_file():
        raise RuntimeError('O clone não contém index.html e includes/js/initial.js. Estrutura upstream alterada.')
    src = index.read_text(encoding='utf-8')
    if '</head>' not in src or '</body>' not in src:
        raise RuntimeError('HTML upstream inesperado: não foi possível inserir a identidade visual.')
    src = src.replace('<title>WebKitty</title>', '<title>AlexGOLDHEN — WebKitty Host</title>')
    src = src.replace('content="WebKitty"', 'content="AlexGOLDHEN"')
    src = src.replace('</head>', '    <link rel="stylesheet" href="./includes/css/colors/alexgoldhen.css">\n</head>', 1)
    src = src.replace('</body>', '    <script src="./includes/js/alexgoldhen-brand.js"></script>\n</body>', 1)
    index.write_text(src, encoding='utf-8')
    original = initial.read_text(encoding='utf-8')
    if 'var projectName = "WebKitty";' not in original:
        raise RuntimeError('Código upstream mudou: variável projectName não encontrada.')
    initial.write_text(original.replace('var projectName = "WebKitty";', 'var projectName = "AlexGOLDHEN";', 1), encoding='utf-8')
    (host / 'includes/assets/branding').mkdir(parents=True, exist_ok=True)
    shutil.copy2(ROOT / 'assets/alexgoldhen.png', host / 'includes/assets/branding/alexgoldhen.png')
    shutil.copy2(ROOT / 'integrations/host-theme.css', host / 'includes/css/colors/alexgoldhen.css')
    shutil.copy2(ROOT / 'integrations/host-brand.js', host / 'includes/js/alexgoldhen-brand.js')
    shutil.copy2(ROOT / 'integrations/host-payload-choice.js', host / 'includes/js/alexgoldhen-payload-choice.js')
    host_html = index.read_text(encoding='utf-8')
    host_html = host_html.replace('</body>', '    <script src="./includes/js/alexgoldhen-payload-choice.js"></script>\n</body>', 1)
    index.write_text(host_html, encoding='utf-8')
    payload_dir = host / 'includes/payloads/HEN'
    payload_dir.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ROOT / 'goldhen.bin', payload_dir / 'alexgoldhen-goldhen.bin')
    shutil.copy2(ROOT / 'hen.bin', payload_dir / 'alexgoldhen-hen.bin')
    # Keep all original WebKitty HEN files, menus and exploit logic unchanged.
    # Preserve all source files, bundled binary assets, copyright info, and upstream license.


def main():
    parser = argparse.ArgumentParser(description='Generate complete deployable AlexGOLDHEN/WebKitty website')
    parser.add_argument('--target', type=Path, default=ROOT / 'dist', help='Output site directory')
    parser.add_argument('--upstream-dir', type=Path, help='Use an already cloned WebKitty directory')
    parser.add_argument('--skip-host', action='store_true', help='Preview portal only; no exploit modules')
    args = parser.parse_args()
    dest = args.target.resolve()
    if dest == ROOT or ROOT in dest.parents and dest.name not in ('dist', 'site'):
        raise RuntimeError('Choose a separate output directory (e.g. dist or site).')
    if dest.exists():
        shutil.rmtree(dest)
    items = uploaded_payloads()
    copy_portal(dest)
    write_payload_manifest(dest, items)
    if args.skip_host:
        print('[preview] Portal copiado. Nenhum host de exploit incluído.')
        return
    if args.upstream_dir:
        origin = args.upstream_dir.resolve()
        if not origin.is_dir():
            raise RuntimeError('Diretório upstream inexistente: ' + str(origin))
        shutil.copytree(origin, dest / 'host', ignore=shutil.ignore_patterns('.git'))
    else:
        subprocess.run(['git', 'clone', '--depth', '1', REPO, str(dest / 'host')], check=True)
        if (dest / 'host/.git').exists():
            shutil.rmtree(dest / 'host/.git')
    patch_host(dest / 'host')
    (dest / 'assets/config.js').write_text('// AlexGOLDHEN — host integrated.\nwindow.ALEX_HOST_READY = true;\n', encoding='utf-8')
    (dest / 'SOURCE.md').write_text(
        '# AlexGOLDHEN — código fonte e créditos\n\n'
        'Interface AlexGOLDHEN com base no WebKitty de ArabPixel.\n\n'
        'Fonte original: https://github.com/ArabPixel/WebKitty\n\n'
        'Fonte personalizada: publique este projeto de build com os arquivos do diretório integrations/.\n\n'
        'Licença do WebKitty: AGPL-3.0-or-later; consulte host/LICENSE.\n', encoding='utf-8')
    print('[complete] Portal e WebKitty incorporados:', dest)
    print('[verify] Uploaded payloads:', ', '.join(item['file'] for item in items))
    print('[verify] Exploit binaries:', len(list((dest / 'host').rglob('*.bin'))))
    print('[verify] Host files:', len([p for p in (dest / 'host').rglob('*') if p.is_file()]))

if __name__ == '__main__':
    try:
        main()
    except (OSError, RuntimeError, subprocess.CalledProcessError) as exc:
        print('ERRO:', exc, file=sys.stderr)
        sys.exit(1)
