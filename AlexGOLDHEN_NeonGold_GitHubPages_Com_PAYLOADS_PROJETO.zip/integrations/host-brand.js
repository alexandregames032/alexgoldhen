/* AlexGOLDHEN — optional credits strip in integrated WebKitty host; no exploit internals modified. */
(function(){'use strict';
  function init(){
    if(document.getElementById('alex-source-band'))return;
    var p=document.createElement('div');p.id='alex-source-band';p.className='alex-source-band';
    p.innerHTML='♛ AlexGOLDHEN · base: <a href="https://github.com/ArabPixel/WebKitty" target="_blank" rel="noopener noreferrer">WebKitty / ArabPixel</a> · <a href="../index.html">Portal</a>';
    document.body.appendChild(p);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init);else init();
})();
