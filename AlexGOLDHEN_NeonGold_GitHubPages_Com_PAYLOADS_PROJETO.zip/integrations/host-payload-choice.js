/* AlexGOLDHEN / ES5 — select an uploaded HEN file in the integrated WebKitty host.
   This script does not auto-execute a jailbreak or transmit files over a network.
   It only sets the local payload_path understood by the original host. */
(function () {
  'use strict';
  var m = /(?:\?|&)alexPayload=(goldhen|hen)(?:&|$)/.exec(window.location.search || '');
  if (!m || !window.storage || !window.storage.session || !window.storage.session.set) return;
  var paths = {
    goldhen: './includes/payloads/HEN/alexgoldhen-goldhen.bin',
    hen: './includes/payloads/HEN/alexgoldhen-hen.bin'
  };
  var chosen = m[1];
  window.storage.session.set('payload_path', paths[chosen]);
  // A visible status label is intentionally used rather than a fake success toast.
  function notice() {
    if (document.getElementById('alex-payload-notice')) return;
    var el = document.createElement('div');
    el.id = 'alex-payload-notice';
    el.className = 'alex-payload-notice';
    el.appendChild(document.createTextNode('AlexGOLDHEN | Arquivo selecionado: ' + (chosen === 'goldhen' ? 'goldhen.bin' : 'hen.bin') + ' | Aguardando ação no host'));
    document.body.appendChild(el);
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', notice); else notice();
})();
