# Licenciamento

As alterações de interface e o programa de build AlexGOLDHEN são oferecidos nos termos da AGPL-3.0-or-later quando combinados com WebKitty. A licença integral e os créditos do WebKitty são preservados em `host/LICENSE` e `host/README.md` após o build completo. Texto da licença: https://www.gnu.org/licenses/agpl-3.0.html

Repositório original: https://github.com/ArabPixel/WebKitty
